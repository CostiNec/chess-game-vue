<template>
  <div class="lds-facebook">
      AI is thinking ....
  </div>
</template>

<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "Loader"
}
</script>
